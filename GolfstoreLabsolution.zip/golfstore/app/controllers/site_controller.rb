class SiteController < ApplicationController
  def about
  end

  def contact
  end
end
